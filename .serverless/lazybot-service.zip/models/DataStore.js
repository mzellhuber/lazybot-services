module.exports = function() {
    return {
        userData: {},
        sessionData: {},
        intent: '',
        slots: [],
        response: {}
    }
}